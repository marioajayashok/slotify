<?php

if(isset($_POST["loginButton"]))
 {
    echo "Login Button was clicked";
 }