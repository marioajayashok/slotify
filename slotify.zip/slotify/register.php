<?php
    include("includes/classes/Account.php");
    $account = new Account();
   
    include("includes/handlers/register-handler.php");
    include("includes/handlers/login-handler.php");

?>







<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Slotify</title>
</head>
<body>
    <div id="loginContainer">
        <form id="loginForm" action="register.php" method="POST">
            <h2>Login to your account</h2>
            <p>
                <label for="loginUsername">Username:</label>
                <input type="text" id="loginUsername" name="loginUsername" placeholder="E.g Bart Simpson" required></p>
           <p> 
            <label for="loginPassword">Password:</label>
            <input id="loginPassword" name="loginPassword" type="password" placeholder="Your Password" required>
            </p>

            <button type="submit" name="loginButton">Login</button>

        </form>

        <form id="registerForm" action="register.php" method="POST">
            <h2>Create your Account</h2>
            <p>
                <label for="username">Username:</label>
                <input type="text" id="username" name="username" placeholder="E.g Bart Simpson" required>
            </p>

           <p>
                <label for="firstName">First Name:</label>
                <input type="text" id="firstName" name="firstName" placeholder="E.g Bart" required>
            </p>

           <p>
                <label for="lastName">Last Name:</label>
                <input type="text" id="lastName" name="lastName" placeholder="E.g Simpson" required>
           </p>

           <p>
                <label for="email">Email:</label>
                <input type="email" id="email" name="email" placeholder="bart@gmail.com" required>
           </p>

           <p>
                <label for="email2">Confirm Email:</label>
                <input type="email" id="email2" name="email2" placeholder="bart@gmail.com" required>
           </p>

           
            <p>
            <label for="password">Password:</label>
            <input id="password" name="password" type="password" placeholder="Your Password" required>
            </p>

            <p>
            <label for="password2">Confirm Password:</label>
            <input id="password2" name="password2" type="password" placeholder="Your Password" required>
            </p>

            <button type="submit" name="registerButton">Sign up</button>

        </form>
    </div>
</body>
</html>